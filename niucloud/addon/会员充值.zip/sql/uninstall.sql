
DROP TABLE IF EXISTS `{{prefix}}recharge_order`;

DROP TABLE IF EXISTS `{{prefix}}recharge_order_item`;

DROP TABLE IF EXISTS `{{prefix}}recharge_order_item_refund`;

DROP TABLE IF EXISTS `{{prefix}}recharge_order_log`;
