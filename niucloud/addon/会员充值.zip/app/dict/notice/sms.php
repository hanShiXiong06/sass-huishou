<?php
return [
    'recharge_success' => [
        'content' => '您充值金额￥{price}, 充值后金额￥{balance}',
    ]

];
