<?php
return [
    'recharge_success' => [
        'temp_key' => '52552',
        'keyword_name_list' => [ '充值时间', '充值金额' ],
        'content' => [
            [ '充值时间', '{time}', 'time1' ],
            [ '充值金额', '{price}', 'amount3' ],
        ]
    ]
];