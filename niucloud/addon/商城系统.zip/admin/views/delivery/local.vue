<template>
    <div class="main-container">
        <div class="detail-head">
            <div class="left" @click="back">
                <span class="iconfont iconxiangzuojiantou !text-xs"></span>
                <span class="ml-[1px]">{{ t('returnToPreviousPage') }}</span>
            </div>
            <span class="adorn">|</span>
            <span class="right">{{ pageName }}</span>
        </div>
        <el-card class="box-card !border-none" shadow="never">
            <el-form label-width="120px" ref="formRef" :rules="formRules" :model="formData" class="page-form"
                v-loading="loading">
                <el-form-item :label="t('deliveryAddress')" prop="delivery_address">
                    <div class="flex flex-col">
                        <div class="flex">
                            {{ defaultDeliveryAddress ? defaultDeliveryAddress.full_address :
                                t('defaultDeliveryAddressEmpty') }}
                            <el-button type="primary" @click="router.push('/shop/address')" link class="ml-[10px]">{{
                                defaultDeliveryAddress ? t('update') : t('toSetting')
                            }}</el-button>
                        </div>
                        <div class="text-error leading-none"
                            v-if="formData.center.lat && defaultDeliveryAddress && (formData.center.lat != defaultDeliveryAddress.lat || formData.center.lng != defaultDeliveryAddress.lng)">
                            {{ t('deliveryAddressChange') }}</div>
                    </div>
                </el-form-item>
                <el-form-item :label="t('deliveryType')" prop="delivery_type">
                    <el-checkbox-group v-model="formData.delivery_type">
                        <el-checkbox label="business">{{ t('business') }}</el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
                <el-form-item :label="t('feeType')">
                    <el-radio-group v-model="formData.fee_type">
                        <el-radio label="region">{{ t('region') }}</el-radio>
                        <el-radio label="distance">{{ t('distance') }}</el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-form-item :label="t('feeSetting')" prop="distance" v-show="formData.fee_type == 'distance'">
                    <div class="flex">
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model.number="formData.base_dist" type="text" />
                        </div>
                        {{ t('feeSettingTextOne') }}
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model="formData.base_price" type="text" />
                        </div>
                        {{ t('feeSettingTextTwo') }}
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model.number="formData.grad_dist" type="text" />
                        </div>
                        {{ t('feeSettingTextThree') }}
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model="formData.grad_price" type="text" />
                        </div>
                        {{ t('priceUnit') }}
                    </div>
                </el-form-item>
                <el-form-item :label="t('weightFee')" prop="">
                    <div class="flex">
                        {{ t('weightFeeTextOne') }}
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model="formData.weight_start" type="text" />
                        </div>
                        {{ t('weightFeeTextTwo') }}
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model="formData.weight_unit" type="text" />
                        </div>
                        {{ t('weightFeeTextThree') }}
                        <div class="w-[60px] mx-[5px]">
                            <el-input v-model="formData.weight_price" type="text" />
                        </div>
                        {{ t('priceUnit') }}
                    </div>
                </el-form-item>

                <el-form-item prop="area" v-loading="mapLoading">
                    <div class="relative">
                        <div id="container" class="w-full h-[520px]"></div>
                        <div class="absolute bg-white w-[270px] h-[500px] z-[1000] top-[10px] left-[10px] region-list">
                            <el-scrollbar>
                                <div class="p-[10px] region-item pr-[50px] relative" v-for="(item, index) in formData.area"
                                    :key="index" :class="{ '!border-primary': index == currArea }"
                                    @click="selectArea(index)">
                                    <el-form label-width="80px" :model="item" :rules="formRules" class="page-form"
                                        ref="areaFromRef">
                                        <div class="pb-[18px]">
                                            <el-form-item :label="t('areaName')" prop="area_name">
                                                <el-input v-model="formData.area[index].area_name" type="text" />
                                            </el-form-item>
                                        </div>
                                        <div class="pb-[18px]">
                                            <el-form-item :label="t('startPrice')" prop="start_price">
                                                <el-input v-model="formData.area[index].start_price" type="text" />
                                            </el-form-item>
                                        </div>
                                        <div class="pb-[10px]" v-show="formData.fee_type == 'region'">
                                            <el-form-item :label="t('deliveryPrice')" prop="delivery_price">
                                                <el-input v-model="formData.area[index].delivery_price" type="text" />
                                            </el-form-item>
                                        </div>
                                        <el-form-item :label="t('areaType')">
                                            <el-radio-group v-model="formData.area[index].area_type" @click.stop=""
                                                @change="areaTypeChange(index)">
                                                <el-radio label="radius" size="large" class="!mr-[10px]">{{ t('radius')
                                                }}</el-radio>
                                                <el-radio label="custom" size="large" class="!mr-[0px]">{{ t('custom')
                                                }}</el-radio>
                                            </el-radio-group>
                                        </el-form-item>
                                    </el-form>
                                    <el-button type="primary" link class="absolute z-1 top-[10px] right-[10px]"
                                        @click.stop="deleteArea(index)">{{
                                            t('delete')
                                        }}</el-button>
                                </div>
                                <div class="p-[10px] text-center">
                                    <el-button type="default" plain @click="addArea">{{ t('addDeliveryArea') }}</el-button>
                                </div>
                            </el-scrollbar>
                        </div>
                    </div>
                </el-form-item>
            </el-form>
        </el-card>
        <div class="fixed-footer-wrap">
            <div class="fixed-footer">
                <el-button type="primary" @click="onSave(formRef)" :disabled="loading">{{ t('save') }}</el-button>
                <el-button @click="back()">{{ t('cancel') }}</el-button>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { t } from '@/lang'
import { useRoute, useRouter } from 'vue-router'
import { getMap } from '@/app/api/sys'
import { guid } from '@/utils/common'
import { createCircle, deleteGeometry, createPolygon, selectGeometry, createMarker } from '@/utils/qqmap'
import { setLocal, getLocal } from '@/shop/api/delivery'
import { FormInstance } from 'element-plus'
import Test from '@/utils/test'
import { getShopDefaultDeliveryAddressInfo } from '@/shop/api/shop_address'

const route = useRoute()
const router = useRouter()
const loading = ref(false)
const pageName = route.meta.title
const formRef = ref<FormInstance>()
const areaFromRef = ref<FormInstance[]>()

const defaultDeliveryAddress = ref(null)
const getDefaultDeliveryAddress = async () => {
    await getShopDefaultDeliveryAddressInfo().then(({ data }) => {
        defaultDeliveryAddress.value = data
    }).catch()
}
getDefaultDeliveryAddress()

const formData = ref({
    center: {
        lat: '',
        lng: ''
    },
    delivery_type: ['business'],
    fee_type: 'region',
    base_dist: '',
    base_price: '',
    grad_dist: '',
    grad_price: '',
    weight_start: 0.000,
    weight_unit: 0,
    weight_price: 0,
    area: [
        {
            area_name: '',
            area_type: 'radius',
            start_price: 0,
            delivery_price: 0,
            area_json: {
                key: guid()
            }
        }
    ]
})

// 表单验证规则
const formRules = computed(() => {
    return {
        delivery_address: [
            {
                validator: (rule: any, value: any, callback: any) => {
                    if (!defaultDeliveryAddress.value) {
                        callback(new Error(t('defaultDeliveryAddressEmpty')))
                    }
                    callback()
                }
            }
        ],
        delivery_type: [
            {
                validator: (rule: any, value: any, callback: any) => {
                    if (!formData.value.delivery_type.length) {
                        callback(new Error(t('deliveryTypeRequire')))
                    }
                    callback()
                }
            }
        ],
        distance: [
            {
                validator: (rule: any, value: any, callback: any) => {
                    if (formData.value.fee_type == 'distance') {
                        if (Test.require(formData.value.base_dist)) {
                            callback(new Error(t('baseDistRequire')))
                        }
                        if (Test.require(formData.value.base_price)) {
                            callback(new Error(t('basePriceRequire')))
                        }
                        if (Test.require(formData.value.grad_dist)) {
                            callback(new Error(t('gradDistRequire')))
                        }
                        if (Test.require(formData.value.grad_price)) {
                            callback(new Error(t('gradPriceRequire')))
                        }
                    }
                    callback()
                },
                trigger: 'blur'
            }
        ],
        area_name: [{ required: true, message: t('areaNameRequire'), trigger: 'blur' }],
        start_price: [
            { required: true, message: t('startPriceRequire'), trigger: 'blur' },
            { min: 0, message: t('startPriceMin'), trigger: 'blur' }
        ],
        delivery_price: [
            { required: formData.value.fee_type == 'region', message: t('deliveryPriceRequire'), trigger: 'blur' },
            { min: 0, message: t('deliveryPriceMin'), trigger: 'blur' }
        ],
        area: [
            {
                validator: (rule: any, value: any, callback: any) => {
                    if (Test.empty(formData.value.area)) {
                        callback(new Error(t('areaPlaceholder')))
                    }
                    callback()
                },
                trigger: 'blur'
            }
        ]
    }
})

getLocal().then(({ data }) => {
    if (data) Object.assign(formData.value, data)
}).catch()

onMounted(() => {
    const mapScript = document.createElement('script')
    getMap().then(res => {
        mapScript.type = 'text/javascript'
        mapScript.src = 'https://map.qq.com/api/gljs?libraries=tools,service&v=1.exp&key=' + res.data.key
        document.body.appendChild(mapScript)
    })
    mapScript.onload = () => {
        setTimeout(() => {
            initMap()
        }, 500)
    }
})

/**
 * 初始化地图
 */
let map: any
const mapLoading = ref(true)
const initMap = () => {
    const TMap = (window as any).TMap
    const LatLng = TMap.LatLng
    const center = new LatLng(defaultDeliveryAddress.value ? defaultDeliveryAddress.value.lat : 39.980619, defaultDeliveryAddress.value ? defaultDeliveryAddress.value.lng : 116.321277)

    map = new TMap.Map('container', {
        center,
        zoom: 14
    })
    createMarker(map)

    map.on('tilesloaded', () => {
        mapLoading.value = false
    })

    formData.value.area.forEach(item => {
        item.area_type == 'radius' ? createCircle(map, item.area_json) : createPolygon(map, item.area_json)
    })
}

const currArea = ref<number>(0)

/**
 * 添加配送区域
 */
const addArea = () => {
    formData.value.area.push({
        area_name: '',
        area_type: 'radius',
        start_price: 0,
        delivery_price: 0,
        area_json: {
            key: guid()
        }
    })
    const index = formData.value.area.length - 1
    createCircle(map, formData.value.area[index].area_json)
}

/**
 * 删除配送区域
 */
const deleteArea = (index: number) => {
    const data = formData.value.area[index]
    deleteGeometry(data.area_json.key)
    formData.value.area.splice(index, 1)
}

const selectArea = (index: number) => {
    currArea.value = index
    const data = formData.value.area[index]
    selectGeometry(data.area_json.key)
}

const areaTypeChange = (index: number) => {
    const data = formData.value.area[index]
    deleteGeometry(data.area_json.key)
    data.area_type == 'radius' ? createCircle(map, data.area_json) : createPolygon(map, data.area_json)
}

onBeforeUnmount(() => {
    map.destroy()
})

const onSave = async (formEl: FormInstance | undefined) => {
    if (loading.value || !formEl) return

    await formEl.validate(async (valid) => {
        let areaValidate = true

        for (let i = 0; i < areaFromRef.value?.length; i++) {
            const ref = areaFromRef.value[i]
            await ref.validate(async (valid) => {
                areaValidate = valid
            })
            if (!areaValidate) break
        }
        if (!areaValidate) return

        if (valid) {
            loading.value = true

            formData.value.center = {
                lat: defaultDeliveryAddress.value.lat,
                lng: defaultDeliveryAddress.value.lng
            }

            await formEl.validate(async (valid) => {
                setLocal(formData.value).then(() => {
                    loading.value = false
                }).catch(() => {
                    loading.value = false
                })
            })
        }
    })
}

const back = () => {
    router.push({ path: '/shop/order/delivery' })
}
</script>

<style lang="scss" scoped>
.region-list {
    border: 1px solid var(--el-border-color-lighter);

    .region-item {
        border: 1px solid transparent;
        border-bottom-color: var(--el-border-color-lighter);
    }
}
</style>
