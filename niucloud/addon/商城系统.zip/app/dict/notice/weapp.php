<?php
return [
    'recharge_success' => [
        'tid' => '755',
        'content' => [
            ['交易单号', '{trade_no}', 'keyword1'],
            ['充值金额', '{price}', 'keyword2'],
            ['账户余额', '{balance}', 'keyword3'],
            ['充值时间', '{time}', 'keyword4'],
        ],
        'kid_list' => [1, 3, 4, 2],
        'scene_desc' => ''
    ]
];