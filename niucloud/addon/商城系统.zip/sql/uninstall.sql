
DROP TABLE IF EXISTS `{{prefix}}shop_address`;

DROP TABLE IF EXISTS `{{prefix}}shop_cart`;

DROP TABLE IF EXISTS `{{prefix}}shop_coupon`;

DROP TABLE IF EXISTS `{{prefix}}shop_coupon_goods`;

DROP TABLE IF EXISTS `{{prefix}}shop_coupon_member`;

DROP TABLE IF EXISTS `{{prefix}}shop_delivery_company`;

DROP TABLE IF EXISTS `{{prefix}}shop_delivery_deliver`;

DROP TABLE IF EXISTS `{{prefix}}shop_delivery_local_delivery`;

DROP TABLE IF EXISTS `{{prefix}}shop_delivery_shipping_template`;

DROP TABLE IF EXISTS `{{prefix}}shop_delivery_shipping_template_item`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_brand`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_category`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_collect`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_evaluate`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_label`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_service`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_sku`;

DROP TABLE IF EXISTS `{{prefix}}shop_goods_spec`;

DROP TABLE IF EXISTS `{{prefix}}shop_invoice`;

DROP TABLE IF EXISTS `{{prefix}}shop_order`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_delivery`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_discount`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_discount_goods`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_goods`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_log`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_refund`;

DROP TABLE IF EXISTS `{{prefix}}shop_order_refund_log`;

DROP TABLE IF EXISTS `{{prefix}}shop_stat`;

DROP TABLE IF EXISTS `{{prefix}}shop_store`;
