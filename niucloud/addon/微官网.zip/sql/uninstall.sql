
DROP TABLE IF EXISTS `{{prefix}}cms_article`;

DROP TABLE IF EXISTS `{{prefix}}cms_article_category`;
