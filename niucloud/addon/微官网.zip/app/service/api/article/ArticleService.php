<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\cms\app\service\api\article;

use addon\cms\app\model\article\CmsArticle;
use core\base\BaseApiService;
use think\db\exception\DataNotFoundException;
use think\db\exception\DbException;
use think\db\exception\ModelNotFoundException;

/**
 * 文章服务层
 * Class ArticleService
 * @package app\service\api\article
 */
class ArticleService extends BaseApiService
{

    public function __construct()
    {
        parent::__construct();
        $this->model = new CmsArticle();
    }

    /**
     * 获取文章列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'id, category_id, title, intro, summary, image, author, content, visit, visit_virtual, is_show, sort, create_time, update_time';
        $order = 'create_time desc';
        $search_model = $this->model->withSearch([ 'title', 'category_id'], $where)->with('cmsArticleCategory')->field($field)->order($order)->append(['image_thumb_mid']);
        return $this->pageQuery($search_model);
    }

    /**
     * 文章列表
     * @param array $where
     * @param int $limit
     * @return array
     * @throws DataNotFoundException
     * @throws DbException
     * @throws ModelNotFoundException
     */
    public function getAll(array $where = [], int $limit = 0){
        $field = 'id, category_id, title, intro, summary, image, author, content, visit, visit_virtual, is_show, sort, create_time, update_time';
        $order = 'create_time desc';
        return $this->model->where([ ['is_show', '=', 1]])->withSearch([ 'title', 'category_id', 'ids' ], $where)->limit($limit)->with('cmsArticleCategory')->field($field)->append(['image_thumb_mid'])->order($order)->select()->toArray();
    }

    /**
     * 获取文章信息
     * @param int $id
     * @return array
     */
    public function getInfo(int $id)
    {
        $field = 'id, category_id, title, intro, summary, image, author, content, visit, visit_virtual, is_show, sort, create_time, update_time';

        return $this->model->with('cmsArticleCategory')->field($field)->where([ [ 'id', '=', $id ] ])->append(['image_thumb_big'])->findOrEmpty()->toArray();
    }

}
