<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\cms\app\service\api\article;

use addon\cms\app\model\article\CmsArticleCategory;
use core\base\BaseApiService;

/**
 * 文章分类（栏目）服务层
 * Class ArticleService
 * @package app\service\api\article
 */
class ArticleCategoryService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new CmsArticleCategory();
    }

    /**
     * 获取文章分类列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'category_id, name, sort, is_show, create_time, update_time';
        $order = 'create_time desc';
        $search_model = $this->model->withSearch(['name'], $where)->field($field)->order($order);
        return $this->pageQuery($search_model);
    }

    /**
     * 获取文章分类信息
     * @param int $id
     * @return array
     */
    public function getInfo(int $id)
    {
        $field = 'category_id, name, sort, is_show, create_time, update_time';
        return  $this->model->field($field)->where([['category_id', '=', $id]])->findOrEmpty()->toArray();
    }
}
