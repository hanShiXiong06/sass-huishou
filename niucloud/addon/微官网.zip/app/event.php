<?php

return [
    'listen' => [
        'WapIndex' => [ 'addon\cms\app\listener\WapIndexListener' ],
    ]
];